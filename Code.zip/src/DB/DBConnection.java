package DB;

public class DBConnection {

	public DBConnection() {
		// TODO Auto-generated constructor stub
	}

}
